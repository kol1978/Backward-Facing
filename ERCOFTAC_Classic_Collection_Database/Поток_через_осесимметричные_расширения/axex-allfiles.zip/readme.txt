Axisymmetric Expansions Data File Names
=======================================

The datafiles containing profiles of the mean velocities and Reynolds 
stresses are located in theree directories, corresponding to the three 
cases with different step angles: 14deg, 18deg and 90deg.

With each directory, each file contains profiles at a particular streamwise
location and orientation of the measurement probe. The file names are of 
the form cxxyszzz.dat

xx is a two digit number corresponding to the step angle of the case.

y is either "a" or "b". The "a" files correspond to data with the probe 
aligned to measure u and w velocity components; the "b" files are from 
the probe aligned to measure u and v components.

s is either "m" or "p", and indicates whether the location of the profile
is upstream of the step corner ("m") or downstream iof it ("p").

zzz is a 3 digit number giving the distance of the profile (in mm) i
upstream or downstream from the step corner.

For example:
c90bp040.dat contains data of u and v measurements from the 90 degree case, 
at a location 40 mm downstream of the step corner.
