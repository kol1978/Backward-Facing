  
The accompanying files contain the data described by 
  
 R.D. Mehta, D.H. Wood and P.D. Clausen, 
"Some effects of swirl on turbulent mixing layer development",
Physics of Fluids A, vol. 3 (1991), pp. 2716 - 2724. 
  
The nominal value of the reference velocity U0 is 15 m/sec.
  

STRUCTURE OF THE SET OF THE PROCESSED FILES  
-------------------------------------------

  The data is split into many small files, each containing one table.
  A header is in each file, giving information to identify the file/profiles.

  Example:

### filename = s0_x231v.dat
###--------------------------------------
## Swirling Mixing Layer Experiments, Newcastle 1990
# SZ Experiments, S = 0, uv-plane data
#
# X/R = 2.31
#
#       ZETA          USTAR         UERF          USQ/UE2   ....
#-----------------------------------------------------------
#@ 23    <-- number of lines to follow 
     0.49152E+01   0.10000E+01   0.10000E+01   0.10319E-03  ....
       ........



Filenames :
===========

Files are named in the following manner:
 
   s"m"_x"nnn""b".dat   -->  uv-plane and uw-plane data
   s"m"_delta.dat       -->  "Mixing Layer Growth" data

   "m" = 10 * Swirl-number
         0  --> S=0
         2  --> S=0.2
         4  --> S=0.4
      
   "nnn" = x/H * 100   

   "b" = v --> uv-plane data
         w --> uw-plane data


Example:  filename =  s2_x038w.dat
           --> S=0.2, X/H= 0.38, uw-plane
  
