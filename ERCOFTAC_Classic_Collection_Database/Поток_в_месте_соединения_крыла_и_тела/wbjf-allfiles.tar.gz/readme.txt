
Hot-Wire Data:
==============

The files are named beginning either with "hw-lhs " or "hw-rhs "
or "hw-up" to denote the location of the data taken."hw-lhs" files
denote the left-hand side of the wing looking upstream, "hw-rhs" files
denote the right-hand side of the wing, and "hw-up" ones denote the 0.75 chord
upstream of the wing measurements. The subsequent numbers show the station 
numbers where the data are taken. The left-hand side files are numbered in 
increasing order proceeding upstream, and the right-hand side files are 
numbered in increasing order proceeding downstream. The 0.75 chord upstream 
profile numbers increase in the +z direction. 

The right-hand side hot wire measurements were made at the same station
locations of the Laser Doppler Velocimeter measurements. The same
extension numbers for the right-hand side hot-wire technique data files
and for the LDV data files show the same station locations. 

The "tc", "fs", "ns" in the file names are used to designate the coordinate 
system the data are presented in (see LDV section for explanation).

In the files first 6 lines give the location of the measurements and the 
flow conditions. Next 2 lines show the title of the measured quantities. 
In the rest of the files, data are given. The data consist of the y location 
of the measurement in inches, U and W components of the mean velocity vector 
nondimensionalized with the daily reference velocity, the Flow Angle in degrees, 
and the u^2, w^2 normal and uw shear stresses nondimensionalized with the square 
of the reference velocity.

################################################################################

LDV Data:
=========

The LDV data are obtained by the Swept Spectrum Analyzer and Burst Spectrum 
Analyzers. The uncertainty of the measured quantities are also presented as 
part of the data.

The files are named starting with "ldv" to denote the data are obtained with 
LDV. The subsequent numbers show the stations where the data is taken. The 
"tc", "fs", "ns", designate the different coordinate systems in which the data 
is presented. "tc" stands for Tunnel Coordinates, "fs" for Free-stream 
Coordinates (where the positive x-axis is in the direction of the mean velocity
at the boundary layer edge), and "ns" for the Normal stress Coordinates (where
the positive x-axis is in the direction of the local mean velocity vector
parallel to the tunnel floor at the y location where the normal stress uu is 
maximum).

In the files, the first 15 lines give several  parameters deduced from the data,
and the parameters of the measurement conditions. The next lines define the
data variables presented in the subsequent tabular format.

The data at each point of the profiles consist of the raw data and the derived 
quantites from the raw data. Each line contains:
y, U, V, W, U uncertainty, V uncertainty, W uncertainty, u^2, v^2, w^2, uv, uw, 
vw, u' uncertainty, v' uncertainty, w' uncertainty, uv uncertainty, uw uncertainty, 
vw uncertainty, N, A1, the Flow angle, the Flow Gradient Angle and the Shear Stress 
Angle.

The y location in each profile is given in inches. U, V, W, mean velocity components 
and the uncertainties on these quantities are given as nondimensionalized with the 
daily reference velocities. u^2, v^2, w^2, uv, uw, vw Reynolds' stresses and the 
uncertainties on the shear stresses only are nondimensionalized with the square of 
the reference velocities.  Instead of defining the uncertainties for the normal 
stresses, the uncertainties for the fluctuating velocities are given. The
uncertainties for the normal stresses can be found by using

     uncertainty of u^2 = [ ( sqrt(u^2) + u' uncertainty )**2 
                              - (sqrt(u^2) - u' uncertainty)**2 ] / 2

The uncertainties of the fluctuating velocities are nondimensionalized with the reference 
velocities.  N is the anisotropy constant, and A1 Townsend's structural parameter (both
defined in the files).  The Flow angle, Flow Gradient Angle and the Shear Stress Angle
are all given in degrees.

################################################################################

Pressure Data:
==============

The pressure data files contain the time mean static pressure data taken with 
Scanivalve and an inclined manometer. The results are presented in pressure 
coefficient form. 

The 4 files are named as, "cp-on", "cp-wall", "cp-far", and "cp-nose", denoting the 
measurements on the wing, on the wall where the wing sits, on a line at z/T=3.17 
(T=2.824 inches, maximum body thickness) to see the blockage effect of the body, and 
detailed measurements close to the nose of the body on the wall, respectively. 

In the files, in the first 7 lines some information about the flow conditions of the 
measurements are given. Next lines contain the data in x/T, y/T, z/T, Cp, order.
