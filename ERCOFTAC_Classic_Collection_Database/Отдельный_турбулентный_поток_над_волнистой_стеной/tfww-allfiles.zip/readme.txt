DNS of separated turbulent flow over a sinusoidal wave at 
Re= U H / nu = 6760. 

All values are made dimensionless with 
mean streamwise velocity  U      = 1 
channel height            H      = 1
density                   rho    = 1
 
The datasets dat01.dat ... dat10.dat contain quantities at the 10 
streamwise positions along one wavelength lambda:

x/lambda = 0.101 0.195 0.304 0.398 0.492 0.601 0.695 0.804 0.898 0.992. 

The values are averages over y-direction, over the 4 positions
of equal phase, and over time (20 samples in 60 < H/U <70).

The location of separation and reattachment are 
x/lambda=0.142 and 0.603, respectively.

i,k are the numbers of interior grid cells in respectively
horizontal and vertical direction. x/lambda and z/H are
the positions of the cell center in respectively
horizontal and vertical direction. For some quantities
the exact positions are shifted by half a mesh cell (XH,ZH) 
from the cell center positions (X,Z) according to the following
table:

Quantity    Position 

 u           XH,Z
 v           X ,Z
 w           XH,ZH
 p           X ,Z
 u'u'        XH,Z
 v'v'        X ,Z
 w'w'        XH,ZH
-u'w'        XH,ZH
 p'p'        X ,Z
