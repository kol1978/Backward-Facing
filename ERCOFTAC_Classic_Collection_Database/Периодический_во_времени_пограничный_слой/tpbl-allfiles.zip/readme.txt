  ***********************************************************
  *                                                         *
  *  TURBULENT OSCILLATORY BOUNDARY LAYERS OVER SMOOTH AND  *
  *                     ROUGH WALLS                         *
  *                                                         *
  *          B.L. JENSEN  M.B. SUMER  J. FREDSOE            *
  *  INSTITUTE OF HYDRODYNAMICS AND HYDRAULIC ENGINEERING   *
  *            TECHNICAL UNIVERSITY OF DENMARK              *
  *         (File edited by P. Bradshaw, Stanford)                                                         *
  ***********************************************************

  THIS DISC CONTAINS DATA OBTAINED WITH LDA AND HOT-FILM MEASUREMENTS
  REPORTED IN THE JFM-PAPER "TURBULENT OSCILLATORY BOUNDARY LAYERS
  AT HIGH RE-NUMBERS", J. FLUID MECH. (1989) VOL 206, PP 265 - 297.

  THE SAME DATA IS REPORTED IN THE PH-D THESIS BY B.L. JENSEN:
  "EXPERIMENTAL INVESTIGATION OF TURBULENT OSCILLATORY BOUNDARY LAYERS"
  (1989), SERIES PAPER NO. 45 ,INST. HYDRODYN. HYDRAULIC ENGRG.,
  TECHN. UNIV. DENMARK BUILD.115 DK-2800 LYNGBY, DENMARK.
  PHONE: + 45 42 88 42 00  OR  + 45 42 88 22 22
  FAX  : + 45 42 93 28 60

  THE DATA IS ORGANIZED IN THE FOLLOWING MANNER:

  <TYPE><TESTNUMBER><COMPONENT>.DAT

  FOR FLOWCONDITIONS CORRESPONDING TO THE DIFFERENT TESTNUMBERS PLEASE
  REFER TO ONE OF THE TWO ABOVEMENTIONED REFERENCES

  THE KEYS FOR THE DIFFERENT TYPES ARE:
  <P> = profiles of statistical values with 15 degr. intervals
        the first column contains the y-positions and the next
        13 columns contain the values from 0 degr. to 180 degr.
  <T> = timeseries of statistical values for different y/a -values
        organized in columns
        The first column contains the phase-values
        The next 5 or 6 columns contain the values corresponding
        to the following y/a-values
         Test 10 : y/a = 0.0003 , 0.001 , 0.004 , 0.012, 0.026 , 0.038
         Test 13 : y/a = 0.0006 , 0.0018 , 0.0058 , 0.017 , 0.038

  THE KEY FOR THE DIFFERENT COMPONENTS IS:
  (REYUV  = REYNOLDS STRESSES)
  (MEAUU  = MEAN IN THE STREAMWISE DIRECTION)
  (RMSUU  = RMS IN THE STREAMWISE DIRECTION)
  (RMSVV  = RMS IN THE VERTICAL DIRECTION.(NORMAL TO THE WALL))


 (THE DATA IN THE PROFILE-FILES ARE LISTED IN THE THESIS)                                                                        00610000

    The Files TAURMS and TAUMEAN contains the timeseries of the
    shearstress measurements (rms and mean respectively)
    The first column contains the phase-values and the next 9
    columns correspond to the following testnumbers:
    1, 2, 3, 4, 5, 7, 8, 9, 10 as can be seen from the testmatrix
    in the paper

    Note that the surface shear stress MAGNITUDE is
tabulated. The shear stress changes sign in the second
half-cycle but the hot-film probe cannot show this.
