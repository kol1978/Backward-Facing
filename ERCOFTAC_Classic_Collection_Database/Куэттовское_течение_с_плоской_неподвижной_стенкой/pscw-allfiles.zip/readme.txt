Couette Flow with Fixed Plane Wall.

* Notations:

x: coordinate along the wall and the mean velocity
y: coordinate normal to the wall and to the mean velocity.

U, V, W: mean velocity components.
u', v', w': square root of the normal Reynolds stresses.
uv, uw: Reynolds shear stresses.

h: channel height: 29.7 mm
u_tau1: friction velocity on the moving lower wall
u_tau2: friction velocity on the fixed upper wall
Uw: moving wall velocity
Uq: mean velocity over the channel height
nu: kinematic viscosity: 15.0 10-6 m2/s

All spectrum are non-dimensionalized by h and Uq.


################################################################################
Pure Poiseuille Flow:
* Files :

       poispur1.dat: All profiles. Mean velocities normalised by Uq, rms and Reynolds stresses by u_tau
       spepo050.dat: One dimensional long. vel. spectrum at y/h=0.50
       spepo075.dat: One dimensional long. vel. spectrum at y/h=0.75
       spepo095.dat: One dimensional long. vel. spectrum at y/h=0.95

################################################################################
Poiseuille-type Flow (Uw=2 m/s):
* Files :

       typpoi5.dat: Profiles at station 5. Mean velocities normalised by Uq, rms and Reynolds stresses by u_tau2
       etabtp.dat: Profiles of mean and rms streamwise velocity, normalized by Uq, at all 5 measurement locations.
       spetp004.dat: One dimensional long. vel. spectrum at y/h=0.04
       spetp050.dat: One dimensional long. vel. spectrum at y/h=0.50
       spetp095.dat: One dimensional long. vel. spectrum at y/h=0.95

################################################################################
Intermediate-type Flow (Uw=3 m/s):
* Files :

       typint5.dat: Profiles at station 5. Mean velocities normalised by Uq, rms and Reynolds stresses by u_tau2
       etabti.dat: Profiles of mean and rms streamwise velocity, normalized by Uq, at all 5 measurement locations.
       speti004.dat: One dimensional long. vel. spectrum at y/h=0.04
       speti050.dat: One dimensional long. vel. spectrum at y/h=0.50
       speti095.dat: One dimensional long. vel. spectrum at y/h=0.95

################################################################################
Couette-type Flow (Uw=5 m/s):
* Files :

       typcou4.dat: Profiles at station 4. Mean velocities normalised by Uq, rms and Reynolds stresses by u_tau2
       typcou5.dat: Profiles at station 5. Mean velocities normalised by Uq, rms and Reynolds stresses by u_tau2
       etabtc.dat: Profiles of mean and rms streamwise velocity, normalized by Uq, at all 5 measurement locations.
       spetc004.dat: One dimensional long. vel. spectrum at y/h=0.04
       spetc050.dat: One dimensional long. vel. spectrum at y/h=0.50
       spetc095.dat: One dimensional long. vel. spectrum at y/h=0.95

################################################################################
