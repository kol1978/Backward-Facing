Main reference
--------------

CLAUSEN, P.D. and KOH, S.G. and WOOD, D.H.,
Measurements of a swirling turbulent boundary layer developing in a
conical diffuser, 
Exptl. Thermal and Fluid Sci. 6, 39, 1993


Files
-----

cp.dat		contains the Cp data plotted in fig. 2.

mm???.dat 	contains U, W in m/s (from which fig. 3 was plotted) and 
         	all the wall shear stress and mass/momentum flux values given in Table 1. 
                The last entry for each x is the extrapolated value at the diffuser centtreline.
		y is in mm.
 
The normalized mean velocity and Reynolds stress data are in the files ending -25.dat 025.dat etc.,
corresponding to the x-location given in Table 1. The beginning of the file name give the mean velocity
or stress component:

u*         u
w*         w
usq*       uu
vsq*       vv
wsq*       ww
uv*        uv
vw*        vw
uw*        uw

The data is in the order of y (mm) followed by the particular velocity or stress.
The mean velocities are normalized by U0.  The Reynolds stresses have been normalised by U0**2 and 
are factored by 100 so that, for example, the first axial normal stress at the inlet (at y = 4.0 mm 
in usq-25.dat) is 0.7647147*10-2

location | mm     U       W      usq      uv      uw      vsq      vw      wsq 
------------------------------------------------------------------------------
-25      | *      *       *       *       *        *       *        *       *
025      | *      *       *       *       *        *       *        *       *
060      | *      *       *       *       *        *       *        *       *
100      | *      *       *       *       *        *       *        *       *
175      | *      *       *       *       *        *       *        *       *
250      | *      *       *       *       *        *       *        *       *
330      | *      *       *       *       *        *       *        *       *
405      | *      *       *       *       *        *       *        *       *
------------------------------------------------------------------------------

